<?php

namespace ideas\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use ideas\Http\Requests;
use ideas\Http\Requests\VentaFormRequest;
use Illuminate\Support\Facades\Input;
use ideas\Venta;
use ideas\Articulo;
use ideas\DetalleVenta;
use DB;

use Carbon\Carbon;
use Response;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Facades\Excel;

class VentaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        if($request)
        {
            if($request->get('daterange') == null || $request->get('daterange') == ''){
                $mytime= Carbon::now('America/Argentina/Buenos_Aires');
                $date=$mytime->toDateTimeString();
                $pieces[0] = $date;
                $yearago = $mytime->subYears(1);
                $date2 = $yearago->toDateTimeString();
                $pieces[1] = $date2;
                $ventas = DB::table('venta as v')
                    ->join('persona as p', 'v.idcliente' , '=', 'p.idpersona')
                    ->join('detalle_venta as dv', 'v.idventa', '=', 'dv.idventa')
                    ->select('v.idventa','v.fecha_hora','p.nombre','v.tipo_comprobante','v.serie_comprobante','v.num_comprobante', 'v.impuesto','v.estado','v.total_venta')
                    ->whereBetween('v.fecha_hora', array(new Carbon($pieces[1]), new Carbon($pieces[0])))
//                ->where('v.num_comprobante', 'LIKE', '%'.$query.'%')
                    ->orderBy('v.idventa','desc')
                    ->groupBy('v.idventa','v.fecha_hora','p.nombre','v.tipo_comprobante','v.serie_comprobante','v.num_comprobante', 'v.impuesto','v.estado','v.total_venta')
                    ->paginate(20);
            } else{

                $date = $request->get('daterange');
                $pieces = explode(" - ", $date);

                $query = trim($request->get('searchText'));
                $ventas = DB::table('venta as v')
                    ->join('persona as p', 'v.idcliente' , '=', 'p.idpersona')
                    ->join('detalle_venta as dv', 'v.idventa', '=', 'dv.idventa')
                    ->select('v.idventa','v.fecha_hora','p.nombre','v.tipo_comprobante','v.serie_comprobante','v.num_comprobante', 'v.impuesto','v.estado','v.total_venta')
//                ->where('v.num_comprobante', 'LIKE', '%'.$query.'%')
                    ->whereBetween('v.fecha_hora', array(new Carbon($pieces[0]), new Carbon($pieces[1])))
                    ->orderBy('v.idventa','desc')
                    ->groupBy('v.idventa','v.fecha_hora','p.nombre','v.tipo_comprobante','v.serie_comprobante','v.num_comprobante', 'v.impuesto','v.estado','v.total_venta')
                    ->paginate(20);
            }
//            echo $pieces[0];

            return view('ventas.venta.index', ['ventas'=>$ventas, 'date' => $date]);
        }
    }

    public function create()
    {
        $personas=DB::table('persona')->where('tipo_persona','=','Cliente')->get();
        $proveedores=DB::table('persona')->where('tipo_persona','=','Proveedor')->where('estado','=','Activo')->get();
        $articulos = Articulo::where('estado','=','Activo')->get();
        return view('ventas.venta.create', ['personas'=>$personas,'articulos'=>$articulos, 'proveedores'=>$proveedores]);
    }

    public function edit($id)
    {
        $venta=Venta::findOrFail($id);

        $detalles= DB::table('detalle_venta')->where('idventa','=',$id)->get();

        $personas=DB::table('persona')->where('tipo_persona','=','Cliente')->get();
        $proveedores=DB::table('persona')->where('tipo_persona','=','Proveedor')->get();
        $articulos=DB::table('articulo as art')
            ->select(DB::raw('CONCAT(art.codigo, " ", art.nombre) AS articulo'), 'art.idarticulo')
//            ->where('art.estado', '=', 'Activo')
            ->get();
        return view('ventas.venta.edit',['venta'=>$venta, 'personas'=>$personas, 'articulos'=>$articulos, 'proveedores'=>$proveedores, 'detalles'=> $detalles]);
    }

    public function store(VentaFormRequest $request)
    {
        try
        {
            DB::beginTransaction();
            $venta = new Venta;
            $venta->idcliente=$request->get('idcliente');
            $venta->tipo_comprobante=$request->get('tipo_comprobante');
            $venta->serie_comprobante=$request->get('serie_comprobante');
            $venta->num_comprobante=$request->get('num_comprobante');
            $venta->total_venta=$request->get('total_venta');
            $venta->idvendedor = auth()->user()->id;
            $mytime= Carbon::now('America/Argentina/Buenos_Aires');

            $venta->fecha_hora=$mytime->toDateTimeString();
            $venta->impuesto='0';
            $venta->estado='Activo';
            $venta->save();

            $idarticulo = $request->get('idarticulo');
            $cantidad = $request->get('cantidad');
//            $descuento = $request->get('descuento');
            $precio_venta = $request->get('precio_venta');

            $cont = 0;

            while($cont < count($idarticulo)){
                $detalle = new DetalleVenta();
                $detalle->idventa = $venta->idventa;
                $detalle->idarticulo = $idarticulo[$cont];
                $detalle->cantidad = $cantidad[$cont];
//                $detalle->descuento = $descuento[$cont];
                $detalle->precio_venta = $precio_venta[$cont];
                $detalle->save();
                $cont= $cont+1;
            }
            DB::commit();
        }
        catch(\Exception $e)
        {
            DB::rollback();
        }


        return Redirect::to('ventas/venta');
    }

    public function update(VentaFormRequest $request,$id)
    {
        try
        {
            DB::beginTransaction();

            DB::table('detalle_venta')->where('idventa', $id)->delete();

            $venta = Venta::findOrFail($id);
            $venta->idcliente=$request->get('idcliente');
            $venta->tipo_comprobante=$request->get('tipo_comprobante');
            $venta->serie_comprobante=$request->get('serie_comprobante');
            $venta->num_comprobante=$request->get('num_comprobante');
            $venta->total_venta=$request->get('total_venta');
            $venta->idvendedor = auth()->user()->id;
            $mytime= Carbon::now('America/Argentina/Buenos_Aires');

            $venta->fecha_hora=$mytime->toDateTimeString();
            $venta->impuesto='0';
            $venta->estado='Activo';
            $venta->save();

            $idarticulo = $request->get('idarticulo');
            $cantidad = $request->get('cantidad');
//            $descuento = $request->get('descuento');
            $precio_venta = $request->get('precio_venta');

            $cont = 0;

            while($cont < count($idarticulo)){
                $detalle = new DetalleVenta();
                $detalle->idventa = $venta->idventa;
                $detalle->idarticulo = $idarticulo[$cont];
                $detalle->cantidad = $cantidad[$cont];
//                $detalle->descuento = $descuento[$cont];
                $detalle->precio_venta = $precio_venta[$cont];
                $detalle->save();
                $cont= $cont+1;
            }
            DB::commit();
        }
        catch(\Exception $e)
        {
            DB::rollback();
        }

        return Redirect::to('ventas/venta');
    }

    public function show($id)
    {
        $venta =  DB::table('venta as v')
            ->join('persona as p', 'v.idcliente' , '=', 'p.idpersona')
            ->join('detalle_venta as dv', 'v.idventa', '=', 'dv.idventa')
            ->select('v.idventa','v.fecha_hora','p.nombre','v.tipo_comprobante','v.serie_comprobante','v.num_comprobante', 'v.impuesto','v.estado','v.total_venta')
            ->where('v.idventa', '=', $id)
            ->first();

        $detalles =  DB::table('detalle_venta as d')
            ->join('articulo as a','d.idarticulo', '=', 'a.idarticulo')
            ->select('a.nombre as articulo','d.cantidad', 'd.descuento', 'd.precio_venta')
            ->where('d.idventa','=', $id)->get();


        return view('ventas.venta.show',['venta'=>$venta, 'detalles'=>$detalles]);
    }

    public function destroy($id)
    {
        $venta = Venta::findOrFail($id);
        $venta->estado = 'Cancelado';
        $venta->update();
        return Redirect::to('ventas/venta');
    }
    public function buscarArticuloPorProveedor(Request $request){


        //if our chosen id and products table prod_cat_id col match the get first 100 data

        //$request->id here is the id of our chosen option id
        $data= DB::table('articulo as art')->select('art.idarticulo','art.nombre','art.codigo')->where('art.proveedor','=',$request->codigo)->get();
        //$data= DB::table('articulo as art')->join('persona as p', 'p.codigo' , '=', 'art.proveedor')->select('art.idarticulo','art.nombre','art.codigo','id.persona')->where('p.codigo','=',$request->codigo)->get();

        // $data= DB::table('articulo as art')->where('idarticulo','=',$request->id);
        //$data=Product::select('productname','id')->where('prod_cat_id',$request->id)->take(100)->get();
        return response()->json($data);//then sent this data to ajax success

//        $request->id here is the id of our chosen option id
//        $data=DB::table('articulo as art')->select('idarticulo','nombre')->get();
//        //$data=Product::select('productname','id')->where('prod_cat_id',$request->id)->take(100)->get();
//        return response()->json($data);//then sent this data to ajax success
    }

    public function buscarPrecioArticuloVentas(Request $request){


    //if our chosen id and products table prod_cat_id col match the get first 100 data
    //$request->id here is the id of our chosen option id
    $precio= DB::table('precio')
        ->where('idarticulo','=',$request->id)
        ->orderBy('idarticulo','desc')
        ->orderBy('idprecio','desc')
        ->get();
    $precio = $precio->unique('idarticulo');
    $articulo = Articulo::findOrFail($request->id);
    //$elprecio = DB::table('articulo')join('precio','idarticulo','=',$precio->idarticulo)->get();
    //$data= DB::table('articulo as art')->join('persona as p', 'p.codigo' , '=', 'art.proveedor')->select('art.idarticulo','art.nombre','art.codigo','id.persona')->where('p.codigo','=',$request->codigo)->get();
    $precio = $precio->merge($articulo);

    // $data= DB::table('articulo as art')->where('idarticulo','=',$request->id);
    //$data=Product::select('productname','id')->where('prod_cat_id',$request->id)->take(100)->get();
    return response()->json($precio);//then sent this data to ajax success

//        $request->id here is the id of our chosen option id
//        $data=DB::table('articulo as art')->select('idarticulo','nombre')->get();
//        //$data=Product::select('productname','id')->where('prod_cat_id',$request->id)->take(100)->get();
//        return response()->json($data);//then sent this data to ajax success
}

    public function buscarPrecioArticuloVentasPorCodigo(Request $request){


        //if our chosen id and products table prod_cat_id col match the get first 100 data
        //$request->id here is the id of our chosen option id
        $articulo = DB::table('articulo')->where('codigo','=',$request->codigo)->first();

        $precio= DB::table('precio')
            ->where('idarticulo','=',$articulo->idarticulo)
            ->orderBy('idarticulo','desc')
            ->orderBy('idprecio','desc')
            ->get();
        $precio = $precio->unique('idarticulo');
        //$elprecio = DB::table('articulo')join('precio','idarticulo','=',$precio->idarticulo)->get();
        //$data= DB::table('articulo as art')->join('persona as p', 'p.codigo' , '=', 'art.proveedor')->select('art.idarticulo','art.nombre','art.codigo','id.persona')->where('p.codigo','=',$request->codigo)->get();
        $precio = $precio->merge($articulo);

        // $data= DB::table('articulo as art')->where('idarticulo','=',$request->id);
        //$data=Product::select('productname','id')->where('prod_cat_id',$request->id)->take(100)->get();
        return response()->json($precio);//then sent this data to ajax success

//        $request->id here is the id of our chosen option id
//        $data=DB::table('articulo as art')->select('idarticulo','nombre')->get();
//        //$data=Product::select('productname','id')->where('prod_cat_id',$request->id)->take(100)->get();
//        return response()->json($data);//then sent this data to ajax success
    }

    public function export(Request $request,$date)
    {

        if($date != null && $date != '' && strtotime($date)){
            $pieces = explode(" - ", $date);

            $aux = DB::table('articulo as a')
                ->join('detalle_venta as dv','dv.idarticulo','=','a.idarticulo')
                ->join('venta as v','v.idventa','=','dv.idventa')
                ->select('a.nombre', 'dv.precio_venta',  DB::raw('SUM(dv.cantidad) AS cantidad'), DB::raw('SUM(dv.precio_venta*dv.cantidad) AS precio_total'))
//                ->whereBetween('v.fecha_hora', array(new Carbon($pieces[0]), new Carbon($pieces[1])))
                ->groupBy('a.nombre','dv.precio_venta')
                ->get();




        }
        else {

            $aux = DB::table('articulo as a')
                ->join('detalle_venta as dv','dv.idarticulo','=','a.idarticulo')
                ->join('venta as v','v.idventa','=','dv.idventa')
                ->select('a.nombre', 'dv.precio_venta',  DB::raw('SUM(dv.cantidad) AS cantidad'), DB::raw('SUM(dv.precio_venta*dv.cantidad) AS precio_total'))
                ->groupBy('a.nombre','dv.precio_venta')
                ->get();
        }

        $columna = [];
        $cont2 = 1;
        $total = 0;
        $fila0 = [];
        $fila0[0] = 'Nombre';
        $fila0[1] = 'Precio Venta';
        $fila0[2] = 'Cantidad';
        $fila0[3] = 'Precio total';
        $columna[0] = $fila0;

        foreach ($aux as $a) {
            $fila = [];

            $fila[0] = $a->nombre;
            $fila[1] = $a->precio_venta;
            $fila[2] = $a->cantidad;
            $fila[3] = $a->precio_total;
            $total = $total + $fila[3];
            $columna[$cont2] = $fila;
            $cont2 = $cont2 + 1;
        }
        $filanueva = [];
        $filanueva[0] = ' ';
        $filanueva[1] = ' ';
        $filanueva[2] = ' ';
        $filanueva[3] = $total;
        $columna[$cont2] = $filanueva;

        Excel::create('Laravel Excel', function($excel) use($columna){

            $excel->sheet('Excel sheet', function($sheet) use ($columna){

            $sheet->row(1, ['Nombre', 'Precio venta', 'Cantidad', 'Precio total']);
                    $sheet->fromArray($columna, null, 'A1', false, false);

            });

        })->download('xls');
    }
}
