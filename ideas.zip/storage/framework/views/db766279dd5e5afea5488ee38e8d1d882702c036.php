<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <h3>
            Listado de Artículos
            <a href="articulo/create"><button class="btn btn-success">Nuevo</button></a>
            <a href="<?php echo e(URL::action('ArticuloController@exportArticulo',$selectText)); ?>"><button class="btn btn-success">Exportar Resultado</button></a>
        </h3>

    </div>
 </div>
<div class="row">
    <?php echo $__env->make('almacen.articulo.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="row">
     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
         <div class="table-responsive">
             <table class="table table-striped table-bordered table-condensed table-hover">
                 <thead>
                     <th>Nombre</th>
                     <th>Codigo</th>
                     <th>Precio</th>
                     <th>Categoría</th>
                     <th>Estado</th>
                     <th>Opciones</th>
                 </thead>
                 <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><?php echo e($art->nombre); ?></td>
                     <td><?php echo e($art->codigo); ?></td>
                     <td><?php echo e($art->ultimoprecio); ?></td>
                     <td><?php echo e($art->categoria); ?></td>
                     <td><?php echo e($art->estado); ?></td>
                     <td>
                         <a href="<?php echo e(URL::action('ArticuloController@edit',$art->idarticulo)); ?>"><button class="btn btn-info">Editar</button></a>
                         <a href="<?php echo e(URL::action('ArticuloController@cambiarEstadoArticulo',$art->idarticulo)); ?>"><button class="btn btn-warning">Cambiar estado</button></a>
                         <a href="" data-target="#modal-delete-<?php echo e($art->idarticulo); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
                     </td>
                 </tr>
                 <?php echo $__env->make('almacen.articulo.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </table>
         </div>
         <?php echo $articulos->appends(['selectText' => $selectText, 'searchText' => $searchText, 'searchText2' => $searchText2])->render(); ?>

     </div>
 </div>
 <?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>
 <script>
     var val = getURLParameter('selectText');
     $('#selectText').val(val);

     function getURLParameter(name) {
         return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null
     }



</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>