<?php echo Form::open(array('url'=>'almacen/articulo', 'method'=>'GET', 'autocomplete'=>'off', 'role'=>'search', 'class'=>'form-horizontal')); ?>

<div class="container">
    <div class="form-group">
        <label class="col-md-4 control-label">Nombre del artículo</label>
        <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-check"></i></span>
                <input type="text" class="form-control" name="searchText" placeholder="Buscar por nombre del artículo..." value="<?php echo e($searchText); ?>">
            </div>
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-4 control-label">Código del artículo</label>
        <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-check"></i></span>
                <input type="text" class="form-control" name="searchText2" placeholder="Buscar..." value="<?php echo e($searchText2); ?>">
            </div>
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-4 control-label">Estado del artículo</label>
        <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-check"></i></span>
                <select class="form-control" id="selectText" name="selectText">
                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($estado->estado); ?>"><?php echo e($estado->estado); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-4 control-label">Acción</label>
        <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
               <span class="input-group-btn">
            <button type="submit" class="btn btn-primary">Filtrar</button>
                </span>
            </div>
        </div>
    </div>
</div>
<?php echo e(Form::close()); ?>