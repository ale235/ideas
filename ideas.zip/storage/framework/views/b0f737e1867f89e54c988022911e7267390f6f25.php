<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <h3>
            Listado de Ventas
        </h3>
        <a href="venta/create"><button class="btn btn-success pull-left">Nueva Venta</button></a>
        <a href="<?php echo e(URL::action('VentaController@export',$date)); ?>"><button class="btn btn-success pull-right">Exportar Resultado <i class="fa fa-file-excel-o"></i></button></a>
        <a href="<?php echo e(URL::action('VentaController@export',$date)); ?>"><button class="btn btn-success pull-right">Exportar Resultado con Detalle<i class="fa fa-file-excel-o"></i></button></a>
        <a href="<?php echo e(URL::action('VentaController@export',$date)); ?>"><button class="btn btn-success pull-right">Caja del día<i class="fa fa-file-excel-o"></i></button></a>
        <?php echo $__env->make('ventas.venta.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Fecha</th>
                    <th>Cliente</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Opciones</th>
                </thead>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($vent->fecha_hora); ?></td>
                    <td><?php echo e($vent->nombre); ?></td>
                    <td><?php echo e($vent->total_venta); ?></td>
                    <td><?php echo e($vent->estado); ?></td>
                    <td>
                        <a href="<?php echo e(URL::action('VentaController@show',$vent->idventa)); ?>"><button class="btn btn-primary">Detalles</button></a>
                        
                        <a href="" data-target="#modal-delete-<?php echo e($vent->idventa); ?>" data-toggle="modal"><button class="btn btn-danger">Anular</button></a>
                    </td>
                </tr>
                <?php echo $__env->make('ventas.venta.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <?php echo e($ventas->render()); ?>

        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
//        var start = moment();
//        var end = moment();
//        var d = new Date();
//        d.setHours(0,0,0);
        $('input[name="daterange"]').daterangepicker(
            {
                locale: {
//                    useCurrent: false,
                    format: 'YYYY-MM-DD h:mm A',
//                    defaultDate: d
                },

//                startDate: start,
//                endDate: end,
        }
        );

    });
    $('#bt_add').click(function () {
        console.log($('input[name="daterange"]').val())
    });
    var val = getURLParameter('daterange');
    $('#daterange').val(val);

    function getURLParameter(name) {
        return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null
    }




</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>