<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});

Route::resource('almacen/categoria','CategoriaController');
Route::resource('precios/actualizar','PrecioController');
Route::resource('almacen/articulo','ArticuloController');
Route::resource('reportes/grafico','ReportesController');
Route::get('/test', 'ReportesController@projectsChartData');
Route::resource('ventas/cliente','ClienteController');
Route::resource('compras/proveedor','ProveedorController');
Route::resource('compras/ingreso','IngresoController');
Route::resource('ventas/venta','VentaController');
Route::resource('seguridad/usuario','UsuarioController');

Auth::routes();

Route::get('/home', 'HomeController@index');
Route::get('/prodview','ArticuloController@prodfunct');
Route::get('/findProductName','ArticuloController@findProductName');
Route::get('/findPrice','ArticuloController@findPrice');
Route::get('/exportArticulo/{selectText}','ArticuloController@exportArticulo');

Route::get('/articulosSinStock','ReportesController@articulosSinStock');
Route::get('/cajaDelDia','ReportesController@cajaDelDia');
Route::get('/cajaDeAyer','ReportesController@cajaDeAyer');
Route::get('/ventasPorProductos','ReportesController@ventasPorProductos');
Route::get('/proveedorQueMasProductosVende','ReportesController@proveedorQueMasProductosVende');


Route::get('/buscarPrecioArticuloVentasPorCodigo','VentaController@buscarPrecioArticuloVentasPorCodigo');


Route::get('/mostrarPrecio/{id}','ArticuloController@mostrarPrecio');


//Route::get('/export','VentaController@export');
Route::get('/export/{daterange}','VentaController@export');


Route::get('/buscarArticuloPorProveedorEnIngreso','IngresoController@buscarArticuloPorProveedorEnIngreso');
Route::get('/buscarArticuloPorProveedor','VentaController@buscarArticuloPorProveedor');
Route::get('/buscarArticuloPorProveedor','PrecioController@buscarArticuloPorProveedor');
Route::get('/buscarArticuloPorPrecioYPorProveedor','PrecioController@buscarArticuloPorPrecioYPorProveedor');
Route::get('/buscarPrecioArticuloVentas','VentaController@buscarPrecioArticuloVentas');
Route::get('/buscarPrecioArticulo','PrecioController@buscarPrecioArticulo');
Route::get('/logout', 'Auth\LoginController@logout');

Route::get('/editarEstado/{id}', 'CategoriaController@editarEstado');

Route::get('/cambiarEstadoArticulo/{id}', 'ArticuloController@cambiarEstadoArticulo');
Route::get('/cambiarEstado/{id}', 'ProveedorController@cambiarEstado');

Auth::routes();
